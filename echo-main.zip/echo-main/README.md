# Your name

FIRST NAME: <Replace this with your first name>

LAST NAME: <Replace this with your last name>

# Echo

Creates a new string that repeats the given string `str` `n` number of times. Each one should be in its own line. For example: if `str` is `'Hello!'`, and `n` is 3, then it should be `'Hello!\nHello!\nHello!\n'`